package ar.edu.centro8.ps.tpfinalps.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import ar.edu.centro8.ps.tpfinalps.model.Producto;
import ar.edu.centro8.ps.tpfinalps.repository.ProductoRepository;

import java.util.List;

@RestController
@RequestMapping("/api/productos")
public class ProductoController {

@Autowired
    private ProductoRepository productoRepository;

    // 1. Listar todos los productos
    @GetMapping
    @PreAuthorize("hasAuthority('READ')")
    public ResponseEntity<List<Producto>> getAllProductos() {
        List<Producto> productos = productoRepository.findAll();
        return ResponseEntity.ok(productos);
    }

    // 2. Obtener un producto por ID
    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Producto> getProductoById(@PathVariable Long id) {
        return productoRepository.findById(id)
            .map(ResponseEntity::ok)
            .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // 3. Crear un nuevo producto
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Producto> createProducto(@RequestBody Producto producto) {
        Producto nuevo = productoRepository.save(producto);
        return ResponseEntity.ok(nuevo);
    }

    // 4. Actualizar un producto existente
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Producto> updateProducto(
            @PathVariable Long id,
            @RequestBody Producto datosProducto) {

        return productoRepository.findById(id).map(prod -> {
            prod.setNombreProducto(datosProducto.getNombreProducto());
            prod.setCategoria(datosProducto.getCategoria());
            prod.setPrecioUnitario(datosProducto.getPrecioUnitario());
            Producto actualizado = productoRepository.save(prod);
            return ResponseEntity.ok(actualizado);
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // 5. Eliminar un producto
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')") 
    public ResponseEntity<String> deleteProducto(@PathVariable Long id) {
        return productoRepository.findById(id).map(prod -> {
            productoRepository.deleteById(id);
            //return ResponseEntity.noContent().<Void>build();
            return ResponseEntity.ok("Producto eliminado correctamente");
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }
}