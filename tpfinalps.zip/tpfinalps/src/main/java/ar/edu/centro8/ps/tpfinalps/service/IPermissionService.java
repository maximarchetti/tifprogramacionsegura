package ar.edu.centro8.ps.tpfinalps.service;

import java.util.List;
import java.util.Optional;
import ar.edu.centro8.ps.tpfinalps.model.Permission;

public interface IPermissionService {

List<Permission> findAll();
    Optional<Permission> findById(Long id);
    Permission save(Permission permission);
    void deleteById(Long id);
    Permission update(Permission permission);

}
