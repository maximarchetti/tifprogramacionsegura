package ar.edu.centro8.ps.tpfinalps.security.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import ar.edu.centro8.ps.tpfinalps.security.config.filter.JwtTokenValidator;
import ar.edu.centro8.ps.tpfinalps.utils.JwtUtils;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Autowired
    private JwtUtils jwtUtils;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
        return httpSecurity
                .csrf(csrf -> csrf.disable())
                .httpBasic(Customizer.withDefaults())
                .oauth2Login(Customizer.withDefaults())
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
          //Public y Swagger
        .requestMatchers(
          "/auth/login", "/auth/logout",
          "/swagger-ui.html", "/swagger-ui/**", "/v3/api-docs/**",
          "/holanoseg"
        ).permitAll()
          //Hello segura
        .requestMatchers("/decirholasec").authenticated()  
        //USERS, ROLES y PERMISSIONS (solo ADMIN)
        .requestMatchers("/api/users/**").hasRole("ADMIN")
        .requestMatchers("/api/roles/**").hasRole("ADMIN")
        .requestMatchers("/api/permissions/**").hasRole("ADMIN")
        //PRODUCTOS
        .requestMatchers(HttpMethod.GET, "/api/productos").hasAuthority("READ")
        .requestMatchers("/api/productos/**").hasRole("ADMIN")
        //PEDIDOS
        .requestMatchers(HttpMethod.GET, "/api/pedidos").hasAnyRole("ADMIN","USER")
        .requestMatchers(HttpMethod.GET, "/api/pedidos/**").hasAuthority("READ")
        .requestMatchers("/api/pedidos/**").hasAnyRole("ADMIN","USER")
        //Todo lo demás requiere autenticación
                        .anyRequest().authenticated())
                .addFilterBefore(new JwtTokenValidator(jwtUtils), BasicAuthenticationFilter.class)
                .build();
    }

    // creamos authentication manager
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration)
            throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }

    // creamos authentication provider
    // Agregamos el user Details Service como parámetro
    @Bean
    public AuthenticationProvider authenticationProvider(UserDetailsService userDetailsService) {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setPasswordEncoder(passwordEncoder());
        // sacamos el anterior, el lógico y agregamos el nuevo
        provider.setUserDetailsService(userDetailsService);

        return provider;
    }

    // password encoder
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

}
