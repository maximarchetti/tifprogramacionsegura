package ar.edu.centro8.ps.tpfinalps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpfinalpsApplicationTests {

	@Test
	void contextLoads() {
	}

}
