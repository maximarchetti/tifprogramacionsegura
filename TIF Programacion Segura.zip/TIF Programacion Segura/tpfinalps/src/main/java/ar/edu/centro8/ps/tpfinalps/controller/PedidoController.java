package ar.edu.centro8.ps.tpfinalps.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import ar.edu.centro8.ps.tpfinalps.model.Pedido;
import ar.edu.centro8.ps.tpfinalps.model.Producto;
import ar.edu.centro8.ps.tpfinalps.repository.PedidoRepository;
import ar.edu.centro8.ps.tpfinalps.repository.ProductoRepository;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/api/pedidos")
public class PedidoController { 

@Autowired
    private PedidoRepository pedidoRepository;

    @Autowired
    private ProductoRepository productoRepository;

    // 1. Listar todos los pedidos
    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','USER')")
    public ResponseEntity<List<Pedido>> getAllPedidos() {
        List<Pedido> pedidos = pedidoRepository.findAll();
        return ResponseEntity.ok(pedidos);
    }

    // 2. Obtener un pedido por ID
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('READ')")
    public ResponseEntity<Pedido> getPedidoById(@PathVariable Long id) {
        return pedidoRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // 3. Crear un nuevo pedido
    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','USER')")
    public ResponseEntity<Pedido> createPedido(@RequestBody Pedido pedido) {
        // reconstruir la lista de productos a partir de IDs
        Set<Producto> productosValidos = new HashSet<>();
        for (Producto p : pedido.getProductosList()) {
            productoRepository.findById(p.getId())
                .ifPresent(productosValidos::add);
        }
        pedido.setProductosList(productosValidos);

        Pedido nuevo = pedidoRepository.save(pedido);
        return ResponseEntity.ok(nuevo);
    }

    // 4. Actualizar un pedido existente
    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','USER')")
    public ResponseEntity<Pedido> updatePedido(
            @PathVariable Long id,
            @RequestBody Pedido datos) {

        return pedidoRepository.findById(id).map(existente -> {
            existente.setPedido(datos.getPedido());
            existente.setObservaciones(datos.getObservaciones());
            existente.setFecha(datos.getFecha());

            // reconstruir productos
            Set<Producto> productosValidos = new HashSet<>();
            for (Producto p : datos.getProductosList()) {
                productoRepository.findById(p.getId())
                    .ifPresent(productosValidos::add);
            }
            existente.setProductosList(productosValidos);

            Pedido actualizado = pedidoRepository.save(existente);
            return ResponseEntity.ok(actualizado);
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // 5. Eliminar un pedido
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','USER')") 
    public ResponseEntity<String> deletePedido(@PathVariable Long id) {
        return pedidoRepository.findById(id).map(p -> {
            pedidoRepository.deleteById(id);
            //return ResponseEntity.noContent().<Void>build();
            return ResponseEntity.ok("Pedido eliminado correctamente");
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }
}