package ar.edu.centro8.ps.tpfinalps.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.HashSet;
import java.util.Set;
import java.time.LocalDate;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name="pedidos")
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String pedido;
    private String observaciones;
    private LocalDate fecha;

    //Usamos Set porque no permite repetidos
    //List permite repetidos
    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinTable (name = "pedidos_productos", joinColumns = @JoinColumn(name = "pedido_id"),
            inverseJoinColumns=@JoinColumn(name = "producto_id"))
    private Set<Producto> productosList = new HashSet<>();

}
