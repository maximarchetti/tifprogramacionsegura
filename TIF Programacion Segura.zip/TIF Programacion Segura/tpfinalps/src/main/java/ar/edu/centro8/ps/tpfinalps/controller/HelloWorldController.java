package ar.edu.centro8.ps.tpfinalps.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class HelloWorldController {

@GetMapping("/holaseg")
     
    @PreAuthorize("hasRole('ADMIN')")
    public String secHelloWorld() {

        return "Hola Mundo con seguridad";
    }

    @GetMapping("/holanoseg")
    @PreAuthorize("permitAll()")
    public String noSecHelloWorld() {

        return "Hola mundo sin seguridad";
    }

    @GetMapping("/decirholasec")
    @PreAuthorize("isAuthenticated()")
    public String decirHolaSec(){
        return "Hola! Este endpoint esta securizado";


    }
}
